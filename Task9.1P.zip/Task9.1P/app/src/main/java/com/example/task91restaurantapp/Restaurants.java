package com.example.task91restaurantapp;

public class Restaurants {
    private int id;
    private String RestaurantName;
    private double Latitude;
    private double Longitude;

    public Restaurants(int id, String name, double latitude, double longitude) {
        this.id = id;
        RestaurantName = name;
        this.Latitude = latitude;
        this.Longitude = longitude;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getRestaurantName() { return RestaurantName; }

    public void setRestaurantName(String name) { RestaurantName = name; }

    public double getLatitude() { return Latitude; }

    public void setLatitude(double latitude) { this.Latitude = latitude; }

    public double getLongitude() { return Longitude; }

    public void setLongitude(double longitude) { this.Longitude = longitude; }
}
