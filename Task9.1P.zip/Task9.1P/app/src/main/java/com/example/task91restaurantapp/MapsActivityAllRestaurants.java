package com.example.task91restaurantapp;

import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;
import java.util.List;

public class MapsActivityAllRestaurants extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    List<Restaurants> RestaurantList;
    DatabaseHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps_all_restaurants);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        RestaurantList = new ArrayList<>();
        db = new DatabaseHelper(this);
        getAllLocations();
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1){
            recreate();
        }
    }

    private void getAllLocations() {
        Cursor cursor = db.readAllRestaurantData();
        if (cursor.getCount() == 0) { Toast.makeText(this, "There are no locations", Toast.LENGTH_SHORT).show(); }
        else {
            while(cursor.moveToNext()) {
                RestaurantList.add(new Restaurants(cursor.getInt(0),cursor.getString(1),cursor.getDouble(2), cursor.getDouble(3)));
            }
        }
    }
    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        for (int i = 0; i< RestaurantList.size(); i++)
        {
            LatLng place = new LatLng(RestaurantList.get(i).getLatitude(),RestaurantList.get(i).getLongitude());
            mMap.addMarker((new MarkerOptions().position(place)).title(RestaurantList.get(i).getRestaurantName()));
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(place, 8));
        }
    }
}