package com.example.task91restaurantapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.api.Status;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.net.PlacesClient;
import com.google.android.libraries.places.widget.Autocomplete;
import com.google.android.libraries.places.widget.AutocompleteActivity;
import com.google.android.libraries.places.widget.AutocompleteSupportFragment;
import com.google.android.libraries.places.widget.listener.PlaceSelectionListener;
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class AddRestaurant extends AppCompatActivity implements LocationListener {
    EditText placeName;
    EditText locationText;
    Button getCurrentLButton;
    Button showOnMapButton;
    Button saveButton;
    LocationManager locationManager;
    List<Address> addresses;
    String restaurantName;
    double longitude, latitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_restaurant);
        placeName = findViewById(R.id.placeNameTextView);
        locationText = findViewById(R.id.locationTextView);
        getCurrentLButton = findViewById(R.id.getCurrentLButton);
        showOnMapButton = findViewById(R.id.showPlaceButton);
        saveButton = findViewById(R.id.saveButton);
        locationManager = (LocationManager) this.getSystemService(LOCATION_SERVICE);
        Places.initialize(getApplicationContext(), "AIzaSyCWQhvKWtyi_061ycXJ0NrrHjkc1qZUREw");

        locationText.setFocusable(false);
        locationText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<Place.Field> fieldList = Arrays.asList(Place.Field.ADDRESS,Place.Field.LAT_LNG,Place.Field.NAME);
                Intent intent = new Autocomplete.IntentBuilder(AutocompleteActivityMode.OVERLAY,fieldList).build(AddRestaurant.this);
                startActivityForResult(intent,100);
            }
        });
        getCurrentLButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getLocation();
            }
        });
        showOnMapButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                restaurantName = placeName.getText().toString();
                if(latitude != 0 && longitude != 0)
                {
                    Intent intent = new Intent(AddRestaurant.this, MapsActivityRestaurant.class);
                    intent.putExtra("NAME", restaurantName);
                    intent.putExtra("LATITUDE", latitude);
                    intent.putExtra("LONGITUDE", longitude);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(AddRestaurant.this, "No location", Toast.LENGTH_SHORT).show();
                }
            }
        });
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                savePlace();
            }
        });
    }
    @SuppressLint("MissingPermission")
    private void getLocation()
    {
        try
        {
            if(ContextCompat.checkSelfPermission(AddRestaurant.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            {
                ActivityCompat.requestPermissions(AddRestaurant.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},100);
            }
            locationManager  = (LocationManager) getApplicationContext().getSystemService(LOCATION_SERVICE);
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,5000,0, AddRestaurant.this);
        }
        catch (Exception exception)
        {
            exception.printStackTrace();
        }
    }
    @Override
    public void onLocationChanged(@NonNull Location location) {
//        Toast.makeText(this, "" + location.getLatitude()+","+ location.getLongitude(), Toast.LENGTH_SHORT).show();
        latitude =  location.getLatitude();
        longitude =  location.getLongitude();
        try
        {
            Geocoder geocoder = new Geocoder(AddRestaurant.this, Locale.getDefault());
            addresses = geocoder.getFromLocation(location.getLatitude(),location.getLongitude(),1);
            String address = addresses.get(0).getAddressLine(0);
            locationText.setText(address);
        }
        catch (Exception exception)
        {
            exception.printStackTrace();
        }
    }
    private void savePlace() {
        restaurantName = placeName.getText().toString();
        if (restaurantName != null &&latitude != 0 && longitude != 0)
        {
            DatabaseHelper db = new DatabaseHelper(AddRestaurant.this);
            long result = db.addRestaurantLocation(restaurantName,latitude,longitude);
            if(result != -1)
            {
                Intent intent = new Intent(AddRestaurant.this, MapsActivityAllRestaurants.class);
                startActivity(intent);
            }
            else{
                Toast.makeText(this, "Location could not be saved", Toast.LENGTH_SHORT).show();
            }
            finish();
        }
        else{
            Toast.makeText(this, "Some of the fields are empty ", Toast.LENGTH_SHORT).show();
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == RESULT_OK)
        {
            Place place = Autocomplete.getPlaceFromIntent(data);
            locationText.setText(place.getAddress());
            placeName.setText(place.getName());

            latitude = place.getLatLng().latitude;
            longitude = place.getLatLng().longitude;
            restaurantName = place.getName();
        }
        else if (resultCode == AutocompleteActivity.RESULT_ERROR)
        {
            Status status = Autocomplete.getStatusFromIntent(data);
            Toast.makeText(getApplicationContext(),status.getStatusMessage(),Toast.LENGTH_SHORT).show();
        }
    }
}