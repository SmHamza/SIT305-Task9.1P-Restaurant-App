package com.example.task91restaurantapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;


public class DatabaseHelper extends SQLiteOpenHelper {
    Context context;
    public static final String DatabaseName = "Database_new.db";
    public static final int DatabaseVersion = 1;
    public static final String TableName = "Maps";
    public static final String ColumnId = "id";
    public static final String ColumnTitle = "Name";

    public DatabaseHelper(@Nullable Context context) {
        super(context, DatabaseName, null, DatabaseVersion);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + TableName +
                " (" + ColumnId + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ColumnTitle + " TEXT, " +
                "latitude" + " VARCHAR, " +
                "longitude" + " VARCHAR);";
        db.execSQL(query);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TableName);
        onCreate(db);
    }
    public long addRestaurantLocation(String title,double latitude,double longitude)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(ColumnTitle, title);
        cv.put("latitude", latitude);
        cv.put("longitude",longitude);
        long resultValue = db.insert(TableName,null,cv);
        if (resultValue == -1) {
            Toast.makeText(context, "Location could not be added", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(context, "Location was added successfully", Toast.LENGTH_SHORT).show();
        }
        return resultValue;
    }
    Cursor readAllRestaurantData()
    {
        String query = "SELECT * FROM " + TableName;
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = null;
        if(database!= null)
        {
            cursor = database.rawQuery(query,null);
        }
        return cursor;
    }

}
